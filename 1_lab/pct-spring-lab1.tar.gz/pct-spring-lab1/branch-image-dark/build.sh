#!/bin/sh

gcc -g -o prog ./prog.c

